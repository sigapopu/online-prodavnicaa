﻿using Online_prodavnica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_prodavnica.Services
{
    public class KorpaService
    {
        private readonly ApplicationDbContext _db;
        public KorpaService(ApplicationDbContext db) { _db = db; }

        public List<StavkeKorpe> GetKorpa(string userId) =>
            _db.StavkeKorpe
               .Include("Proizvod")
               .Where(s => s.KorisnikId == userId)
               .ToList();

        public void DodajUKorpu(string userId, int proizvodId, int kolicina)
        {
            var stavka = _db.StavkeKorpe
                            .FirstOrDefault(s => s.KorisnikId == userId && s.ProizvodId == proizvodId);
            if (stavka != null)
                stavka.Kolicina += kolicina;
            else
                _db.StavkeKorpe.Add(new StavkeKorpe
                { KorisnikId = userId, ProizvodId = proizvodId, Kolicina = kolicina });
            _db.SaveChanges();
        }

        public void UkloniIzKorpe(int stavkaId)
        {
            var s = _db.StavkeKorpe.Find(stavkaId);
            if (s != null) { _db.StavkeKorpe.Remove(s); _db.SaveChanges(); }
        }

        public decimal UkupnaCena(string userId) =>
            _db.StavkeKorpe
               .Where(s => s.KorisnikId == userId)
               .Sum(s => (decimal?)(s.Kolicina * s.Proizvod.Cena)) ?? 0;
    }
}