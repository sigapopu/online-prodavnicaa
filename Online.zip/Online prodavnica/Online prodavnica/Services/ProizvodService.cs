﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Online_prodavnica.Models;
using PagedList;

namespace Online_prodavnica.Services
{
    public class ProizvodService
    {
        private readonly ApplicationDbContext _db;

        public ProizvodService(ApplicationDbContext db)
        {
            _db = db;
        }

        public IPagedList<Proizvod> GetProizvodi(
            string pretraga, int? kategorijaId, string sortiranje, int stranica)
        {
            var query = _db.Proizvodi
                           .Include("Kategorija")
                           .AsQueryable();

            if (!string.IsNullOrWhiteSpace(pretraga))
                query = query.Where(p =>
                    p.Naziv.Contains(pretraga) ||
                    p.Opis.Contains(pretraga));

            if (kategorijaId.HasValue)
                query = query.Where(p => p.KategorijaId == kategorijaId.Value);

            if (sortiranje == "naziv_desc")
                query = query.OrderByDescending(p => p.Naziv);
            else if (sortiranje == "cena_asc")
                query = query.OrderBy(p => p.Cena);
            else if (sortiranje == "cena_desc")
                query = query.OrderByDescending(p => p.Cena);
            else
                query = query.OrderBy(p => p.Naziv);

            return query.ToPagedList(stranica, 6);
        }

        public Proizvod GetById(int id) =>
            _db.Proizvodi.Include("Kategorija").FirstOrDefault(p => p.Id == id);

        public void Dodaj(Proizvod p) { _db.Proizvodi.Add(p); _db.SaveChanges(); }
        public void Izmeni(Proizvod p) { _db.Entry(p).State = System.Data.Entity.EntityState.Modified; _db.SaveChanges(); }
        public void Obrisi(int id) { var p = _db.Proizvodi.Find(id); if (p != null) { _db.Proizvodi.Remove(p); _db.SaveChanges(); } }

        public Dictionary<string, int> BrojPoKategoriji() =>
            _db.Kategorije
               .Select(k => new { k.Naziv, Broj = k.Proizvodi.Count() })
               .ToDictionary(x => x.Naziv, x => x.Broj);
    }
}