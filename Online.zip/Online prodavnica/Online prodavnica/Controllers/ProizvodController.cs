﻿using Online_prodavnica.Models;
using Online_prodavnica.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Online_prodavnica.Controllers
{
    public class ProizvodController : Controller
    {
        // GET: Proizvod
        private readonly ApplicationDbContext _db = new ApplicationDbContext();
        private readonly ProizvodService _service;

        public ProizvodController()
        {
            _service = new ProizvodService(_db);
        }

        // GET: /Proizvod/ – pretraga, filtriranje, sortiranje, paginacija
        public ActionResult Index(string pretraga, int? kategorijaId,
                                  string sortiranje = "naziv_asc", int stranica = 1)
        {
            ViewBag.Pretraga = pretraga;
            ViewBag.KategorijaId = kategorijaId;
            ViewBag.Sortiranje = sortiranje;
            ViewBag.Kategorije =
                new SelectList(_db.Kategorije.ToList(), "Id", "Naziv", kategorijaId);

            var lista = _service.GetProizvodi(pretraga, kategorijaId, sortiranje, stranica);
            return View(lista);
        }

        // GET: /Proizvod/Detalji/5
        public ActionResult Detalji(int id)
        {
            var p = _service.GetById(id);
            if (p == null) return HttpNotFound();
            return View(p);
        }

        // GET: /Proizvod/Dodaj
        [Authorize(Roles = "Admin")]
        public ActionResult Dodaj()
        {
            ViewBag.Kategorije = new SelectList(_db.Kategorije, "Id", "Naziv");
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
        public ActionResult Dodaj(Proizvod p)
        {
            if (ModelState.IsValid) { _service.Dodaj(p); return RedirectToAction("Index"); }
            ViewBag.Kategorije = new SelectList(_db.Kategorije, "Id", "Naziv", p.KategorijaId);
            return View(p);
        }

        // GET: /Proizvod/Izmeni/5
        [Authorize(Roles = "Admin")]
        public ActionResult Izmeni(int id)
        {
            var p = _service.GetById(id);
            if (p == null) return HttpNotFound();
            ViewBag.Kategorije = new SelectList(_db.Kategorije, "Id", "Naziv", p.KategorijaId);
            return View(p);
        }

        [HttpPost, ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
        public ActionResult Izmeni(Proizvod p)
        {
            if (ModelState.IsValid) { _service.Izmeni(p); return RedirectToAction("Index"); }
            ViewBag.Kategorije = new SelectList(_db.Kategorije, "Id", "Naziv", p.KategorijaId);
            return View(p);
        }

        // GET: /Proizvod/Obrisi/5
        [Authorize(Roles = "Admin")]
        public ActionResult Obrisi(int id)
        {
            var p = _service.GetById(id);
            if (p == null) return HttpNotFound();
            return View(p);
        }

        [HttpPost, ActionName("Obrisi"), ValidateAntiForgeryToken, Authorize(Roles = "Admin")]
        public ActionResult ObrisiPotvrda(int id)
        {
            _service.Obrisi(id);
            return RedirectToAction("Index");
        }
    }
}