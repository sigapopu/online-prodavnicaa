﻿using Online_prodavnica.Models;
using Online_prodavnica.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Online_prodavnica.Controllers
{
    [Authorize(Roles = "Admin")]
    public class StatistikaController : Controller
    {
        // GET: Statistika
        private readonly ApplicationDbContext _db = new ApplicationDbContext();

        public ActionResult Index()
        {
            var service = new ProizvodService(_db);
            var podaci = service.BrojPoKategoriji();
            return View(podaci);
        }
    }
}