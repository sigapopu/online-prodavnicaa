﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using Online_prodavnica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Online_prodavnica.Controllers
{
    public class AuthController : Controller
    {
        private ApplicationDbContext _db = new ApplicationDbContext();

        private UserManager<ApplicationUser> UserManager =>
            new UserManager<ApplicationUser>(
                new UserStore<ApplicationUser>(_db));

        private IAuthenticationManager AuthManager =>
            HttpContext.GetOwinContext().Authentication;

        public ActionResult Register() => View();
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<ActionResult> Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var user = new ApplicationUser
            {
                UserName = model.Email,
                Email = model.Email,
                Ime = model.Ime,
                Prezime = model.Prezime
            };
            var result = await UserManager.CreateAsync(user, model.Lozinka);
            if (result.Succeeded)
            {
                var identity = await UserManager.CreateIdentityAsync(
                    user, DefaultAuthenticationTypes.ApplicationCookie);
                AuthManager.SignIn(new AuthenticationProperties
                { IsPersistent = false }, identity);
                return RedirectToAction("Index", "Proizvod");
            }
            foreach (var e in result.Errors) ModelState.AddModelError("", e);
            return View(model);
        }

        public ActionResult Login() => View();

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var user = await UserManager.FindAsync(model.Email, model.Lozinka);
            if (user == null)
            {
                ModelState.AddModelError("", "Pogrešan email ili lozinka.");
                return View(model);
            }
            var identity = await UserManager.CreateIdentityAsync(
                user, DefaultAuthenticationTypes.ApplicationCookie);
            AuthManager.SignIn(new AuthenticationProperties
            { IsPersistent = false }, identity);
            return RedirectToAction("Index", "Proizvod");
        }

        public ActionResult Logout()
        {
            AuthManager.SignOut();
            return RedirectToAction("Login");
        }
    }
}