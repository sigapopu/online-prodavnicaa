﻿using Microsoft.AspNet.Identity;
using Online_prodavnica.Models;
using Online_prodavnica.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Online_prodavnica.Controllers
{
    [Authorize]
    public class KorpaController : Controller
    {
        // GET: Korpa
        private readonly ApplicationDbContext _db = new ApplicationDbContext();
        private readonly KorpaService _service;

        public KorpaController()
        {
            _service = new KorpaService(_db);
        }

        public ActionResult Index()
        {
            var uid = User.Identity.GetUserId();
            ViewBag.Ukupno = _service.UkupnaCena(uid);
            return View(_service.GetKorpa(uid));
        }

        [HttpPost]
        public ActionResult Dodaj(int proizvodId, int kolicina = 1)
        {
            _service.DodajUKorpu(User.Identity.GetUserId(), proizvodId, kolicina);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Ukloni(int stavkaId)
        {
            _service.UkloniIzKorpe(stavkaId);
            return RedirectToAction("Index");
        }
    }
}