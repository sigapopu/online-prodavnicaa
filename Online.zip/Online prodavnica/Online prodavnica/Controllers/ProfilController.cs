﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Online_prodavnica.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Online_prodavnica.Controllers
{
    [Authorize]
    public class ProfilController : Controller
    {
        // GET: Profil
        private ApplicationDbContext _db = new ApplicationDbContext();

        private UserManager<ApplicationUser> GetUserManager()
        {
            return new UserManager<ApplicationUser>(
                new UserStore<ApplicationUser>(_db));
        }

        public ActionResult Index()
        {
            var userId = User.Identity.GetUserId();
            var userManager = GetUserManager();
            var user = userManager.FindById(userId);

            if (user == null)
                return RedirectToAction("Login", "Auth");

            return View(user);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Index(ApplicationUser model)
        {
            if (!ModelState.IsValid) return View(model);

            var userId = User.Identity.GetUserId();
            var userManager = GetUserManager();
            var user = userManager.FindById(userId);

            user.Ime = model.Ime;
            user.Prezime = model.Prezime;
            user.Adresa = model.Adresa;
            user.Telefon = model.Telefon;

            userManager.Update(user);

            ViewBag.Poruka = "Profil je uspešno ažuriran.";
            return View(user);
        }
    }
}