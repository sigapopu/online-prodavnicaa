﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_prodavnica.Models
{
    public class StavkeKorpe
    {
        public int Id { get; set; }
        public string KorisnikId { get; set; }
        public int ProizvodId { get; set; }

        [Range(1, 100)]
        public int Kolicina { get; set; }

        public virtual Proizvod Proizvod { get; set; }
    }
}