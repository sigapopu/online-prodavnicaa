﻿using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Online_prodavnica.Models
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public DbSet<Proizvod> Proizvodi { get; set; }
        public DbSet<Kategorija> Kategorije { get; set; }
        public DbSet<StavkeKorpe> StavkeKorpe { get; set; }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Proizvod>()
            .Property(p => p.Cena)
            .HasPrecision(18, 2);

            modelBuilder.Entity<Proizvod>()
                .HasRequired(p => p.Kategorija)
                .WithMany(k => k.Proizvodi)
                .HasForeignKey(p => p.KategorijaId);
        }
    }
}   