﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Identity.EntityFramework;
using System.ComponentModel.DataAnnotations;

namespace Online_prodavnica.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required(ErrorMessage = "Ime je obavezno")]
        [StringLength(50)]
        [Display(Name = "Ime")]
        public string Ime { get; set; }

        [Required(ErrorMessage = "Prezime je obavezno")]
        [StringLength(50)]
        [Display(Name = "Prezime")]
        public string Prezime { get; set; }

        [Display(Name = "Adresa")]
        [StringLength(200)]
        public string Adresa { get; set; }

        [Display(Name = "Telefon")]
        [Phone(ErrorMessage = "Neispravan format telefona")]
        public string Telefon { get; set; }
    }
}