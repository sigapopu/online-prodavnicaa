﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Online_prodavnica.Models
{
    public class Kategorija
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Naziv kategorije je obavezan")]
        [StringLength(50)]
        [Display(Name = "Naziv kategorije")]
        public string Naziv { get; set; }

        public virtual ICollection<Proizvod> Proizvodi { get; set; }
    }
}