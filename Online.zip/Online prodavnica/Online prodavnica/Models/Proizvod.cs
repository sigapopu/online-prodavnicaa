﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Online_prodavnica.Models
{
    public class Proizvod
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Naziv je obavezan")]
        [StringLength(100, ErrorMessage = "Maksimalno 100 karaktera")]
        [Display(Name = "Naziv proizvoda")]
        public string Naziv { get; set; }

        [Required(ErrorMessage = "Opis je obavezan")]
        [StringLength(1000)]
        [Display(Name = "Opis")]
        public string Opis { get; set; }

        [Required(ErrorMessage = "Cena je obavezna")]
        [Range(0.01, 999999, ErrorMessage = "Cena mora biti veća od 0")]
        [Display(Name = "Cena (RSD)")]
        
        public decimal Cena { get; set; }

        [Required(ErrorMessage = "Kategorija je obavezna")]
        [Display(Name = "Kategorija")]
        public int KategorijaId { get; set; }

        [Display(Name = "Na stanju")]
        [Range(0, 10000)]
        public int Kolicina { get; set; }

        [Display(Name = "Slika (URL)")]
        [StringLength(500)]
        public string SlikaUrl { get; set; }

        public virtual Kategorija Kategorija { get; set; }
    }
}
