﻿namespace Online_prodavnica.Migrations
{
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.EntityFramework;
    using Online_prodavnica.Models;
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<Online_prodavnica.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(Online_prodavnica.Models.ApplicationDbContext context)
        {
            if (!context.Kategorije.Any())
            {
                var kategorije = new[]
                {
            new Kategorija { Naziv = "Elektronika" },
            new Kategorija { Naziv = "Odeca" },
            new Kategorija { Naziv = "Knjige" },
            new Kategorija { Naziv = "Sport" }
        };
                context.Kategorije.AddRange(kategorije);
                context.SaveChanges();
            }

            if (!context.Proizvodi.Any())
            {
                context.Proizvodi.AddRange(new[]
                {
            new Proizvod {
                Naziv = "iPhone 15",
                Opis = "Apple iPhone 15 128GB, najnoviji model sa odlicnom kamerom.",
                Cena = 89999,
                KategorijaId = 1,
                Kolicina = 10,
                SlikaUrl = "/Content/Images/iphone.jpg"
            },
            new Proizvod {
                Naziv = "Samsung Galaxy S24",
                Opis = "Samsung Galaxy S24 256GB, Android flagship telefon.",
                Cena = 79999,
                KategorijaId = 1,
                Kolicina = 15,
                SlikaUrl = "/Content/Images/samusng.jpg"
            },
            new Proizvod {
                Naziv = "Laptop Lenovo IdeaPad",
                Opis = "Lenovo IdeaPad 15, Intel i5, 16GB RAM, 512GB SSD.",
                Cena = 65000,
                KategorijaId = 1,
                Kolicina = 8,
                SlikaUrl = "/Content/Images/laptop.jpg"
            },
            new Proizvod {
                Naziv = "Nike Air Max",
                Opis = "Sportske patike Nike Air Max, udobne i moderne.",
                Cena = 12999,
                KategorijaId = 2,
                Kolicina = 25,
                SlikaUrl = "/Content/Images/nike.jpg"
            },
            new Proizvod {
                Naziv = "Zimska jakna",
                Opis = "Topla zimska jakna, vodootporna, vise boja.",
                Cena = 8500,
                KategorijaId = 2,
                Kolicina = 20,
                SlikaUrl = "/Content/Images/jakna.jpg"
            },
            new Proizvod {
                Naziv = "C# programiranje",
                Opis = "Knjiga za ucenje C# programiranja od pocetka do naprednog nivoa.",
                Cena = 2500,
                KategorijaId = 3,
                Kolicina = 30,
                SlikaUrl = "/Content/Images/prog.jpg"
            },
            new Proizvod {
                Naziv = "Fudbalska lopta",
                Opis = "Adidas fudbalska lopta, velicina 5, za sve podloge.",
                Cena = 3200,
                KategorijaId = 4,
                Kolicina = 18,
                SlikaUrl = "/Content/Images/lopta.jpg"
            },
            new Proizvod {
                Naziv = "Yoga prostirka",
                Opis = "Antiklizajuca yoga prostirka, debljina 6mm.",
                Cena = 1800,
                KategorijaId = 4,
                Kolicina = 22,
                SlikaUrl = "/Content/Images/joga.jpg"
            }
        });
                context.SaveChanges();
            }
            
            var roleManager = new RoleManager<IdentityRole>(
                new RoleStore<IdentityRole>(context));
            var userManager = new UserManager<ApplicationUser>(
                new UserStore<ApplicationUser>(context));

            
            if (!roleManager.RoleExists("Admin"))
            {
                roleManager.Create(new IdentityRole("Admin"));
            }

            
            if (userManager.FindByEmail("admin@shop.com") == null)
            {
                var admin = new ApplicationUser
                {
                    UserName = "admin@shop.com",
                    Email = "admin@shop.com",
                    Ime = "Admin",
                    Prezime = "Administrator"
                };
                userManager.Create(admin, "Admin123!");
                userManager.AddToRole(admin.Id, "Admin");
            }
        }
    }
}